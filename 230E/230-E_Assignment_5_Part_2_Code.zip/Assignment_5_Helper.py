"""
MFE 230-E Assignment 5 Helper Functions
Author: Nathan Johnson
Date: May 15, 2018
"""

import numpy as np
from scipy import stats

def ols(x, y):
    n = np.shape(x)[0]
    X = np.column_stack((np.ones([n,]), x))
    XX_inv = np.linalg.inv(np.dot(X.T, X))
    b = np.dot(XX_inv, np.dot(X.T, y))
    return b

def beta_cov(x, y, m):
    n = np.shape(x)[0]
    k = np.shape(m)[0]
    X = np.column_stack((np.ones([n,]), x))
    XX_inv = np.linalg.inv(np.dot(X.T, X))
    y_hat = np.dot(X, m)
    epsilon_var = np.dot((y - y_hat).T, (y - y_hat)) / (n - k)
    Sigma = np.multiply(epsilon_var, XX_inv)
    return Sigma

def t_test(m_hat, h_0, std, n, alpha, df):
    m_length = np.shape(m_hat)[0]
    test_stat = np.divide((m_hat - h_0), std)
    critical_value = stats.t.ppf((1 + alpha) / 2, df) * np.ones([m_length, 1])
    reject_idx = np.abs(test_stat) > np.abs(critical_value)
    return test_stat

def R_squared(x, y, m):
    n = np.shape(x)[0]
    X = np.column_stack((np.ones([n,]), x))
    y_hat = np.dot(X, m)
    y_hat_bar = np.mean(y_hat)
    y_bar = np.mean(y)
    r2_num = np.dot((y_hat - y_hat_bar).T, (y_hat - y_hat_bar))
    r2_denom = np.dot((y - y_bar).T, (y - y_bar))
    return r2_num / r2_denom

def llk_archm_fn(r, r_lag, m):
    def llk_archm(theta):
        error = r - theta[0] - theta[1] * r_lag
        error_t = error[m:]
        error_lag = error[0:-1]
        h_t = np.zeros(np.shape(error_t))
        T = np.shape(error_t)[0]
        
        for x in np.arange(0, T):
            h_t[x] = theta[2] + np.dot(theta[3:], np.power(
                    error_lag[x:x + m], 2))
        
        sum_llf = 0
        for t in np.arange(0, T):
            llf_t = -0.5 * np.log(2 * np.pi) - 0.5 * np.log(h_t[t]) - 0.5 * (
                    np.power(error_t[t], 2) / h_t[t])
            sum_llf += llf_t
        
        return -sum_llf
    
    return llk_archm

def llk_garchpq_fn(r, r_lag, p, q):
    def llk_garchpq(theta):
        error = r - theta[0] - theta[1] * r_lag
        error_t = error[q:]
        error_lag = error[0:-1]
        T = np.shape(error_t)[0]
        h_t = np.zeros([T,])
        for t in np.arange(0, p):
            h_t[t] = theta[2] + np.dot(theta[3:3 + q], np.power(
                    error_lag[t:t + q], 2))
        
        for t in np.arange(p, T):
            h_t[t] = theta[2] + np.dot(theta[3:3 + q], np.power(
                    error_lag[t: t + q], 2)) + np.dot(
                    theta[(3 + q):], h_t[(t - p) : t])
        
        sum_llf = 0
        for t in np.arange(0, T):
            llf_t = -0.5 * np.log(2 * np.pi) - 0.5 * np.log(h_t[t]) - (
                    0.5 * (np.power(error_t[t], 2) / h_t[t]))
            sum_llf += llf_t
        
        return -sum_llf
    return llk_garchpq

def archm_vol(r, r_lag, m, theta_hat):
    error = r - theta_hat[0] - theta_hat[1] * r_lag
    error_t = error[m:]
    error_lag = error[0:-1]
    h_t_m = np.zeros(np.shape(error_t))
    T = np.shape(error_t)[0]
    
    for x in np.arange(0, T):
        h_t_m[x] = theta_hat[2] + np.dot(theta_hat[3:], np.power(
                error_lag[x:x + m], 2))
    
    return h_t_m

def garchpq_vol(r, r_lag, p, q, theta):
    error = r - theta[0] - theta[1] * r_lag
    error_t = error[q:]
    error_lag = error[0:-1]
    T = np.shape(error_t)[0]
    h_t = np.zeros([T,])
    for t in np.arange(0,p):
        h_t[t] = theta[2] + np.dot(theta[3:3 + q], np.power(
                error_lag[t:t + q], 2))
        
    for t in np.arange(p, T):
        h_t[t] = theta[2] + np.dot(theta[3:3 + q], np.power(
                error_lag[t: t + q], 2)) + np.dot(
            theta[(3 + q):], h_t[(t - p) : t])
    return h_t

def arch_effect_test(r, r_lag):
    reg_model = ols(r_lag, r)
    error = r - reg_model[0] - reg_model[1] * r_lag
    error_t = error[1:]
    error_lag = error[0:-1]
    
    T = np.shape(error)[0]
    error_model = ols(np.power(error_lag, 2), np.power(error_t, 2))
    R2 = R_squared(np.power(error_lag, 2), np.power(error_t, 2), error_model)
    test_stat = T * R2
    
    critical_value = stats.chi2.ppf(0.95, 1)
    if test_stat >= critical_value:
        return True
    else:
        return False
    












